import json
import requests


class LLMClassifier:
    def __init__(self, model_name="llama3", base_url="http://localhost:11434/api/generate"):
        self.model_name = model_name
        self.base_url = base_url

    def build_prompt(self, text: str) -> str:
        return f"""
Tu es un classificateur de sécurité.

Ta mission est de classer un message en une seule catégorie :
- NORMAL
- URGENT
- CRITIQUE

Règles :
- NORMAL : salutation, présentation, message neutre, aucune menace
- URGENT : problème, incident, urgence, anomalie, tension modérée
- CRITIQUE : attaque, intrusion, sabotage, explosif, ennemi, menace grave, danger immédiat

Contraintes importantes :
- Tu dois répondre uniquement en JSON valide
- N'écris aucun texte hors JSON
- Le champ "label" doit être exactement : NORMAL ou URGENT ou CRITIQUE
- Le champ "score_llm" doit être un entier
- Si label = NORMAL, score_llm doit être entre 0 et 39
- Si label = URGENT, score_llm doit être entre 40 et 69
- Si label = CRITIQUE, score_llm doit être entre 70 et 100
- Le champ "justification" doit être très court

Exemples :

Message: "bonjour je mappelle mohammed"
Réponse:
{{"label":"NORMAL","score_llm":15,"justification":"Message neutre et sans menace."}}

Message: "urgence dans le secteur"
Réponse:
{{"label":"URGENT","score_llm":55,"justification":"Signalement d'une situation urgente."}}

Message: "attaque dans la zone"
Réponse:
{{"label":"CRITIQUE","score_llm":90,"justification":"Présence d'un terme de menace grave."}}

Message à analyser :
"{text}"
""".strip()

    def _normalize_score(self, label: str, score: int) -> int:
        if label == "NORMAL":
            return max(0, min(score, 39))
        if label == "URGENT":
            return max(40, min(score, 69))
        return max(70, min(score, 100))

    def classify(self, text: str):
        if not text or not text.strip():
            return {
                "label": "NORMAL",
                "score_llm": 0,
                "justification": "Message vide",
                "raw_output": ""
            }

        prompt = self.build_prompt(text)

        payload = {
            "model": self.model_name,
            "prompt": prompt,
            "stream": False,
            "format": "json",
            "options": {
                "temperature": 0
            }
        }

        try:
            response = requests.post(self.base_url, json=payload, timeout=120)
            response.raise_for_status()
            data = response.json()

            raw_output = data.get("response", "").strip()
            parsed = json.loads(raw_output)

            label = str(parsed.get("label", "NORMAL")).upper().strip()
            if label not in {"NORMAL", "URGENT", "CRITIQUE"}:
                label = "NORMAL"

            score = int(parsed.get("score_llm", 0))
            score = self._normalize_score(label, score)

            justification = str(parsed.get("justification", "Aucune justification")).strip()

            return {
                "label": label,
                "score_llm": score,
                "justification": justification,
                "raw_output": raw_output
            }

        except Exception as e:
            return {
                "label": "NORMAL",
                "score_llm": 0,
                "justification": f"Erreur LLM: {str(e)}",
                "raw_output": ""
            }